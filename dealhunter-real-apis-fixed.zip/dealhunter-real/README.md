# DealHunter Real APIs

Proyecto completo con React + Vite + Node/Express.

## APIs incluidas

- Steam: vía CheapShark API pública.
- Epic Games: vía GamerPower API pública para juegos gratis/giveaways.
- Mercado Libre México: vía API pública `api.mercadolibre.com/sites/MLM/search`.
- Amazon: conector preparado para Amazon Product Advertising API / Creators API. Requiere credenciales oficiales de afiliado. Sin credenciales muestra una tarjeta indicando que falta configurar Amazon.

## Ejecutar

```bash
npm install
npm run dev
```

Abre:

```text
http://localhost:5173
```

El backend corre en:

```text
http://localhost:3001
```

## Configurar Amazon

Copia `.env.example` a `.env` y llena:

```text
AMAZON_ACCESS_KEY=
AMAZON_SECRET_KEY=
AMAZON_PARTNER_TAG=
AMAZON_REGION=us-east-1
AMAZON_HOST=webservices.amazon.com.mx
```

Después reinicia:

```bash
npm run dev
```

## Nota importante

Amazon no ofrece una API pública abierta sin credenciales. Para datos reales de Amazon necesitas cuenta de afiliado y credenciales oficiales.


## Nota de precios
Steam ahora usa la API oficial de Steam con `cc=mx`, por lo que los precios mostrados son de México y el botón abre la misma ficha de Steam en México. Mercado Libre filtra productos que reportan `original_price` mayor al precio actual para evitar mostrar productos sin descuento.
