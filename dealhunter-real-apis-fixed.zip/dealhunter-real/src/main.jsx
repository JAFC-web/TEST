import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { Search, Star, ExternalLink, Gamepad2, ShoppingBag, Smartphone, Laptop, Home, Tag, SlidersHorizontal, RefreshCw, AlertTriangle } from 'lucide-react'
import './style.css'

const stores = [
  { id: 'all', name: 'Todas', desc: 'Todas las APIs disponibles', className: 'all' },
  { id: 'steam', name: 'Steam', desc: 'Ofertas reales de Steam México', className: 'steam' },
  { id: 'epic', name: 'Epic Games', desc: 'Gratis y giveaways mediante GamerPower', className: 'epic' },
  { id: 'mercadolibre', name: 'Mercado Libre', desc: 'Productos reales con API oficial MLM', className: 'ml' },
  { id: 'amazon', name: 'Amazon', desc: 'Conector oficial PA-API con credenciales', className: 'amazon' },
]

const categories = [
  { id: 'all', name: 'Todas', icon: Tag },
  { id: 'games', name: 'Videojuegos', icon: Gamepad2 },
  { id: 'tech', name: 'Tecnología', icon: Laptop },
  { id: 'phones', name: 'Celulares', icon: Smartphone },
  { id: 'accessories', name: 'Accesorios', icon: ShoppingBag },
  { id: 'home', name: 'Hogar', icon: Home },
]

function money(n){ return Number(n||0).toLocaleString('es-MX', { style:'currency', currency:'MXN', maximumFractionDigits:0 }) }
function storeName(id){ return stores.find(s=>s.id===id)?.name || id }
function badgeStyle(store){ return `badgeStore ${store}` }

function App(){
  const [deals, setDeals] = useState([])
  const [store, setStore] = useState('all')
  const [category, setCategory] = useState('all')
  const [search, setSearch] = useState('')
  const [minDiscount, setMinDiscount] = useState(0)
  const [sort, setSort] = useState('discount')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [updatedAt, setUpdatedAt] = useState('')

  async function loadDeals(params = {}){
    setLoading(true); setError('')
    try{
      const selectedStore = params.store ?? store
      const term = params.search ?? search
      const qs = new URLSearchParams()
      qs.set('store', selectedStore)
      if(term) qs.set('q', term)
      const res = await fetch(`/api/deals?${qs.toString()}`)
      const data = await res.json()
      if(!data.ok) throw new Error(data.error || 'Error cargando ofertas')
      setDeals(data.deals || [])
      setUpdatedAt(data.updatedAt)
    }catch(e){ setError(e.message) }
    finally{ setLoading(false) }
  }

  useEffect(()=>{ loadDeals({store:'all', search:''}) }, [])

  const filtered = useMemo(()=>{
    return deals
      .filter(d => store==='all' || d.store === store)
      .filter(d => category==='all' || d.category === category)
      .filter(d => (d.discount || 0) >= minDiscount)
      .filter(d => (d.title || '').toLowerCase().includes(search.toLowerCase()))
      .sort((a,b)=> sort==='price' ? (a.price||0)-(b.price||0) : sort==='rating' ? (b.rating||0)-(a.rating||0) : (b.discount||0)-(a.discount||0))
  }, [deals, store, category, minDiscount, search, sort])

  return <div className="app">
    <header className="hero">
      <div>
        <span className="pill">DealHunter · APIs reales</span>
        <h1>Encuentra descuentos de Steam, Epic Games, Mercado Libre y Amazon en un solo lugar.</h1>
        <p>Proyecto web completo con backend Node.js. Usa APIs reales para Steam México, Epic/GamerPower y Mercado Libre. Amazon queda preparado para PA-API oficial con credenciales.</p>
        <div className="heroActions">
          <a href="#ofertas" className="mainBtn">Explorar ofertas</a>
          <button className="ghostBtn" onClick={()=>loadDeals()}>Actualizar APIs</button>
        </div>
      </div>
      <div className="storeGrid">
        {stores.filter(s=>s.id!=='all').map(s => <button key={s.id} className={`storeCard ${s.className} ${store===s.id?'active':''}`} onClick={()=>{setStore(s.id); loadDeals({store:s.id})}}>
          <h3>{s.name}</h3><p>{s.desc}</p>
        </button>)}
      </div>
    </header>

    <section id="ofertas" className="layout">
      <aside className="filters">
        <h2><SlidersHorizontal size={20}/> Filtros</h2>
        <label>Buscar producto</label>
        <div className="searchBox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') loadDeals()}} placeholder="Ej. laptop, juego, celular"/></div>
        <button className="fullBtn" onClick={()=>loadDeals()}>Buscar en APIs</button>
        <label>Tienda</label>
        <select value={store} onChange={e=>{setStore(e.target.value); loadDeals({store:e.target.value})}}>{stores.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
        <label>Descuento mínimo: {minDiscount}%</label>
        <input type="range" min="0" max="100" step="5" value={minDiscount} onChange={e=>setMinDiscount(Number(e.target.value))}/>
        <label>Ordenar por</label>
        <select value={sort} onChange={e=>setSort(e.target.value)}><option value="discount">Mayor descuento</option><option value="price">Menor precio</option><option value="rating">Mejor valoración</option></select>
        <label>Categorías</label>
        <div className="catList">{categories.map(c=>{const Icon=c.icon; return <button key={c.id} className={category===c.id?'selected':''} onClick={()=>setCategory(c.id)}><Icon size={16}/>{c.name}</button>})}</div>
      </aside>

      <main className="results">
        <div className="bar">
          <div><h2>Ofertas disponibles</h2><p>Tienda: {storeName(store)} · {filtered.length} resultados {updatedAt && `· actualizado ${new Date(updatedAt).toLocaleTimeString('es-MX')}`}</p></div>
          <button onClick={()=>loadDeals()} disabled={loading}><RefreshCw size={16} className={loading?'spin':''}/> {loading?'Cargando':'Actualizar'}</button>
        </div>

        {error && <div className="error"><AlertTriangle/> {error}</div>}
        {loading && <div className="loading"><div className="loader"/><p>Consultando APIs reales...</p></div>}

        <div className="grid">
          {!loading && filtered.map(d => <article key={d.id} className="card">
            <div className="img"><img src={d.img} alt={d.title} onError={e=>{e.currentTarget.src='https://placehold.co/600x360/111827/e5e7eb?text=Oferta'}}/>{d.discount>0 && <span className="discount">-{d.discount}%</span>}<span className={badgeStyle(d.store)}>{storeName(d.store)}</span></div>
            <div className="info"><div className="meta"><small>{d.source}</small>{d.rating>0 && <small className="rating"><Star size={13} fill="currentColor"/> {Number(d.rating).toFixed(1)}</small>}</div><h3>{d.title}</h3>{d.oldPrice>0 && d.oldPrice!==d.price && <p className="old">{money(d.oldPrice)}</p>}<div className="bottom"><strong>{d.price===0?'GRATIS':money(d.price)}</strong>{d.url && <a href={d.url} target="_blank" rel="noreferrer">Ver oferta <ExternalLink size={14}/></a>}</div></div>
          </article>)}
        </div>
        {!loading && !error && filtered.length===0 && <div className="empty">No hay resultados con esos filtros.</div>}
      </main>
    </section>
  </div>
}

createRoot(document.getElementById('root')).render(<App />)
