import express from 'express'
import cors from 'cors'
import crypto from 'crypto'

const app = express()
const PORT = process.env.PORT || 3001
app.use(cors())
app.use(express.json())

const peso = n => Math.round(Number(n || 0) * 17.5)
const safeImg = text => `https://placehold.co/600x360/111827/e5e7eb?text=${encodeURIComponent(text || 'Oferta')}`

async function getJson(url, options = {}) {
  const res = await fetch(url, { headers: { 'User-Agent': 'DealHunter/1.0', ...(options.headers || {}) }, ...options })
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} :: ${url}`)
  return res.json()
}

function normalizeCategory(text='') {
  const t = text.toLowerCase()
  if (/(game|juego|steam|epic|pc|xbox|playstation|nintendo)/.test(t)) return 'games'
  if (/(phone|celular|iphone|samsung|xiaomi|motorola)/.test(t)) return 'phones'
  if (/(headset|mouse|teclado|control|audifono|audífono|accesorio|keyboard)/.test(t)) return 'accessories'
  if (/(casa|hogar|home|echo|alexa)/.test(t)) return 'home'
  return 'tech'
}

async function steamMexicoSpecials(search = '') {
  // Steam oficial: precios regionales de México (cc=mx) y descuentos reales de Steam
  const url = 'https://store.steampowered.com/api/featuredcategories?cc=mx&l=spanish'
  const data = await getJson(url)
  const items = data?.specials?.items || []
  const term = String(search || '').toLowerCase().trim()
  return items
    .filter(item => item.name && item.id)
    .filter(item => !term || item.name.toLowerCase().includes(term))
    .filter(item => Number(item.discount_percent || 0) > 0)
    .slice(0, 36)
    .map(item => {
      const initial = Math.round(Number(item.original_price || item.final_price || 0) / 100)
      const final = Math.round(Number(item.final_price || 0) / 100)
      return {
        id: `steam-${item.id}`,
        title: item.name,
        store: 'steam',
        category: 'games',
        oldPrice: initial,
        price: final,
        discount: Number(item.discount_percent || 0),
        rating: 0,
        img: item.large_capsule_image || item.header_image || safeImg(item.name),
        url: `https://store.steampowered.com/app/${item.id}/?cc=mx&l=spanish`,
        source: 'Steam México / API oficial'
      }
    })
}

async function gamerPowerEpic() {
  const data = await getJson('https://www.gamerpower.com/api/giveaways')
  return data
    .filter(g => String(g.platforms || '').toLowerCase().includes('epic'))
    .slice(0, 24)
    .map(g => ({
      id: `epic-${g.id}`,
      title: g.title,
      store: 'epic',
      category: 'games',
      oldPrice: 0,
      price: 0,
      discount: 100,
      rating: 0,
      img: g.image || g.thumbnail || safeImg(g.title),
      url: g.open_giveaway_url || g.gamerpower_url,
      source: 'GamerPower / Epic'
    }))
}

async function mercadoLibre(query = 'laptop gamer oferta') {
  const url = new URL('https://api.mercadolibre.com/sites/MLM/search')
  url.searchParams.set('q', query)
  url.searchParams.set('limit', '24')
  const data = await getJson(url)
  return (data.results || [])
    .filter(item => item.price && item.original_price && Number(item.original_price) > Number(item.price))
    .map(item => {
    const oldPrice = item.original_price || item.price
    const discount = item.original_price ? Math.max(0, Math.round(100 - (item.price / item.original_price) * 100)) : 0
    return {
      id: `ml-${item.id}`,
      title: item.title,
      store: 'mercadolibre',
      category: normalizeCategory(item.title),
      oldPrice: Math.round(oldPrice || 0),
      price: Math.round(item.price || 0),
      discount,
      rating: 0,
      img: item.thumbnail?.replace('-I.jpg', '-O.jpg') || safeImg(item.title),
      url: item.permalink,
      source: 'Mercado Libre México'
    }
  })
}

function hmac(key, str, encoding) { return crypto.createHmac('sha256', key).update(str, 'utf8').digest(encoding) }
function sha256(str) { return crypto.createHash('sha256').update(str, 'utf8').digest('hex') }
function getSignatureKey(key, dateStamp, regionName, serviceName) {
  const kDate = hmac('AWS4' + key, dateStamp)
  const kRegion = hmac(kDate, regionName)
  const kService = hmac(kRegion, serviceName)
  return hmac(kService, 'aws4_request')
}

async function amazonPAAPI(query='gaming') {
  const accessKey = process.env.AMAZON_ACCESS_KEY
  const secretKey = process.env.AMAZON_SECRET_KEY
  const partnerTag = process.env.AMAZON_PARTNER_TAG
  const region = process.env.AMAZON_REGION || 'us-east-1'
  const host = process.env.AMAZON_HOST || 'webservices.amazon.com.mx'
  if (!accessKey || !secretKey || !partnerTag) {
    return [{
      id: 'amazon-config', title: 'Amazon requiere credenciales oficiales de afiliado/Creators API', store: 'amazon', category: 'tech',
      oldPrice: 0, price: 0, discount: 0, rating: 0, img: safeImg('Configura Amazon API'), url: 'https://webservices.amazon.com/paapi5/documentation/',
      source: 'Amazon PA-API no configurada'
    }]
  }
  const path = '/paapi5/searchitems'
  const payload = JSON.stringify({
    Keywords: query, SearchIndex: 'All', PartnerTag: partnerTag, PartnerType: 'Associates', Marketplace: 'www.amazon.com.mx',
    Resources: ['Images.Primary.Large','ItemInfo.Title','Offers.Listings.Price','Offers.Listings.SavingBasis','CustomerReviews.StarRating']
  })
  const now = new Date()
  const amzdate = now.toISOString().replace(/[:-]|\.\d{3}/g, '')
  const datestamp = amzdate.slice(0, 8)
  const target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems'
  const headers = {
    'content-encoding': 'amz-1.0', 'content-type': 'application/json; charset=utf-8', host,
    'x-amz-date': amzdate, 'x-amz-target': target
  }
  const signedHeaders = 'content-encoding;content-type;host;x-amz-date;x-amz-target'
  const canonicalHeaders = signedHeaders.split(';').map(k => `${k}:${headers[k]}\n`).join('')
  const canonicalRequest = ['POST', path, '', canonicalHeaders, signedHeaders, sha256(payload)].join('\n')
  const credentialScope = `${datestamp}/${region}/ProductAdvertisingAPI/aws4_request`
  const stringToSign = ['AWS4-HMAC-SHA256', amzdate, credentialScope, sha256(canonicalRequest)].join('\n')
  const signingKey = getSignatureKey(secretKey, datestamp, region, 'ProductAdvertisingAPI')
  const signature = crypto.createHmac('sha256', signingKey).update(stringToSign, 'utf8').digest('hex')
  const authorization = `AWS4-HMAC-SHA256 Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`
  const data = await getJson(`https://${host}${path}`, { method: 'POST', headers: { ...headers, Authorization: authorization }, body: payload })
  const items = data.SearchResult?.Items || []
  return items.map((it, i) => {
    const listing = it.Offers?.Listings?.[0]
    const price = listing?.Price?.Amount || 0
    const old = listing?.SavingBasis?.Amount || price
    return {
      id: `amazon-${it.ASIN || i}`, title: it.ItemInfo?.Title?.DisplayValue || 'Producto Amazon', store: 'amazon', category: normalizeCategory(it.ItemInfo?.Title?.DisplayValue),
      oldPrice: Math.round(old), price: Math.round(price), discount: old && price ? Math.round(100 - price / old * 100) : 0,
      rating: Number(it.CustomerReviews?.StarRating?.Value || 0), img: it.Images?.Primary?.Large?.URL || safeImg('Amazon'), url: it.DetailPageURL,
      source: 'Amazon PA-API'
    }
  })
}

app.get('/api/deals', async (req, res) => {
  const store = req.query.store || 'all'
  const q = req.query.q || ''
  const mlq = req.query.mlq || q || 'ofertas gamer laptop celular audifonos descuento'
  try {
    const tasks = []
    if (store === 'all' || store === 'steam') tasks.push(steamMexicoSpecials(q))
    if (store === 'all' || store === 'epic') tasks.push(gamerPowerEpic())
    if (store === 'all' || store === 'mercadolibre') tasks.push(mercadoLibre(mlq))
    if (store === 'all' || store === 'amazon') tasks.push(amazonPAAPI(q || 'gaming'))
    const results = await Promise.allSettled(tasks)
    const deals = results.flatMap(r => r.status === 'fulfilled' ? r.value : [])
    res.json({ ok: true, count: deals.length, updatedAt: new Date().toISOString(), deals })
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message })
  }
})

app.get('/api/health', (req, res) => res.json({ ok: true }))

app.listen(PORT, () => console.log(`DealHunter API corriendo en http://localhost:${PORT}`))
